<?php
include '../koneksi.php';
$id = $_GET['id'];

$sql = "DELETE FROM petugas WHERE id_petugas='$id'";
$query   = mysqli_query($koneksi, $sql);

if($query){
    ?>
    echo"<script>alert('Data Berhasil Dihapus'); window.location.assign('admin.php?url=lihat-petugas');</script>";
    <?php
}
?>