<?php

?>
<div class="card shadow">
<div class="card-header">
    <a href="?url=verifikasi-pengaduan" class="btn btn-primary btn-icon-split">
        <span class="icon text-white-5">
            <i class="fa fa-arrow-left"></i>
        </span>
        <span class="text">Kembali</span>
    </a>

</div>
<div class="card-body">

<form method="post" action="simpan-tanggapan.php" enctype="multipart/form-data">

    <div class="form-group">
        <label>Tanggal Tanggapan</label>
        <input type="text" name="tgl_tanggapan" class="form-control" readonly value="<?= date('Y-m-d'); ?>">
    </div>

    <div class="form-group">
        <label>Isi Tanggapan</label>
        <textarea name="tanggapan" class="form-control" required></textarea>
    </div>

    <div class="form-group">
        <label>Nama Petugas</label>
        <input type="text" name="id_petugas" class="form-control" readonly value="<?= $_SESSION['nama_petugas']; ?>">
    </div>

    <input type="submit" class="btn btn-primary" value="Tanggapi"></input>

</form>

</div>
</div>