<?php
include '../koneksi.php';
$sql = "UPDATE pengaduan SET STATUS='proses' where id_pengaduan='$_GET[id]'";
$query  = mysqli_query($koneksi, $sql);

if ($sql){
    header("Location:admin.php?url=verifikasi-pengaduan");
}
?>