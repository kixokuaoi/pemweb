         <?php
         session_start();
         ?>
         <!-- DataTales Example -->
          <div class="card shadow mb-4">
          <script>window.print();</script>
            <div class="card-header py-3">
            </div>
            <div class="card-body" style="font-size : 14px">

            <h3 class="m-0 font-weight-bold text-secondary" align="center">PEMERINTAH KABUPATEN A</h3>
            <h4 class="m-0 font-weight-bold text-secondary" align="center">DESA B KECAMATAN C</h4>
            <h6 class="m-0 font-weight-bold text-secondary" align="center">Jalan Yang pernah Ada No.3</h6>
            <br><hr>
            <h6 class="m-0 font-weight-bold text-secondary" align="center">Laporan Petugas</h6>
            <br>

              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tr>
                      <th>ID Petugas</th>
                      <th>Nama Petugas</th>
                      <th>Email</th>
                      <th>Password</th>
                      <th>No. Telepon</th>
                      <th>Level</th>
                    </tr>
                  <tbody>
                    <?php
                    include '../koneksi.php';
                    $sql = "SELECT*FROM petugas";
                    $query = mysqli_query($koneksi, $sql);
                    $no =1;
                    while ($data=mysqli_fetch_array($query))          {   ?>
                    <tr>
                    <td><?= $data['id_petugas']; ?></td>
                    <td><?= $data['nama_petugas']; ?></td>
                      <td><?= $data['email']; ?></td>
                      <td><?= $data['password']; ?></td>
                      <td><?= $data['telp']; ?></td>
                      <td><?= $data['level']; ?></td>         
                    </td>
                    </tr>  
                    <?php } ?>           
                </tbody>     
                </table>

              </div>
              <h6 class="m-0 font-weight-bold text-secondary" align="right">Desa B, <?= date('Y-m-d'); ?></h6>
              <h6 class="m-0 font-weight-bold text-secondary" align="right">Petugas,</h6>
              <br><br><br>
              <h6 class="m-0 font-weight-bold text-secondary" align="right"><?=$_SESSION['nama_petugas']?></h6>


            </div>
          </div>

        