<div class="card shadow mb-4">
<div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Petugas</h6>
</div>
<div class="card-body" style="font-size : 14px">
        <a href="?url=lihat-petugas" class="btn btn-primary btn-icon-split">
                <span class="icon text-white-50">
                    <i class="fa fa-arrow-left"></i>
                </span>
                <span class="text">Kembali</span>
</a><br><br>

<div class="card-body">
<form method="post" action="simpan-petugas.php" enctype="multipart/form-data">

    <div class="form-group">
        <label>Nama Petugas</label>
        <input type="text" name="nama_petugas" class="form-control" value="">
    </div>

    <div class="form-group">
        <label>Email</label>
        <input type="text" name="email" class="form-control" value="">
    </div>

    <div class="form-group">
        <label>Password</label>
        <input type="text" name="password" class="form-control" value="">
    </div>

    <div class="form-group">
        <label>No. Telepon</label>
        <input type="text" name="telp" class="form-control" value="">
    </div>

    <div class="form-group">
        <label>Level</label>
        <select class="form-control" name="level">
            <option>==Pilih Level==</option>
            <option value="admin">Admin</option>
            <option value="petugas">Petugas</option>
    </div>
    
    <div class="form-group col-sm-6">
        <input type="submit" value="Simpan" class="btn btn-success"></button>
        <input type="reset" value="Kosongkan" class="btn btn-warning"></button>
    </div>


</form>

</div>
</div>