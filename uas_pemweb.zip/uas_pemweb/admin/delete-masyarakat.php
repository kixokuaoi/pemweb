<?php
include '../koneksi.php';
$nik = $_GET['nik'];

$sql = "DELETE FROM masyarakat WHERE nik='$nik'";
$query   = mysqli_query($koneksi, $sql);

if($query){
    ?>
    echo"<script>alert('Data Berhasil Dihapus'); window.location.assign('admin.php?url=lihat-masyarakat');</script>";
    <?php
}
?>