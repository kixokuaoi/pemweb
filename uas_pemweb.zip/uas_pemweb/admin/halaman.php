<?php

if(isset($_GET['url'])){
    switch ($_GET['url']) {

        case 'verifikasi-pengaduan';
        include 'verifikasi-pengaduan.php';
        break;

        case 'tanggapi-pengaduan';
        include 'tanggapi-pengaduan.php';
        break;

        case 'detail-pengaduan';
        include 'detail-pengaduan.php';
        break;

        case 'lihat-petugas';
        include 'lihat-petugas.php';
        break;

        case 'tambah-petugas';
        include 'tambah-petugas.php';
        break;

        case 'edit-petugas';
        include 'edit-petugas.php';
        break;

        case 'cetak-petugas';
        include 'cetak-petugas.php';
        break;

        case 'lihat-masyarakat';
        include 'lihat-masyarakat.php';
        break;

        case 'lihat-pengaduan';
        include 'lihat-pengaduan.php';
        break;

    default:
        echo "Halaman Tidak Ditemukan";
        break;
}
}else{
    echo "Selamat Datang di Aplikasi Pelaporan Pengaduan Masyarakat.<br>";
    echo "Anda Login Sebagai : ".$_SESSION['nama_petugas'];

    include '../koneksi.php';
    $sql = "SELECT * FROM pengaduan where status='0'";
    $query  = mysqli_query($koneksi, $sql);

    if ($cek=mysqli_num_rows($query))
    {
    ?>
    <br>
    <br>
    
    <div class="col-xl-6 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Laporan Pengaduan : </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">Ada <?php echo $cek; ?> Laporan Dari Masyarakat</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-4x text-gray-500"></i>
                      <span class="badge badge-danger badge-counter"><?php echo $cek; ?></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

<?php
} }
?>