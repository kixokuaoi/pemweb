<?php
include '../koneksi.php';
$nama = $_POST['nama_petugas'];
$email = $_POST['email'];
$password = $_POST['password'];
$telp = $_POST['telp'];
$level = $_POST['level'];
$id = $_POST['id_petugas'];

$sql = "UPDATE petugas SET nama_petugas='$nama', email='$email', password='$password', telp='$telp', level='$level' WHERE id_petugas='$id'";
$query   = mysqli_query($koneksi, $sql);

if($query){
    ?>
    echo"<script>alert('Data Berhasil Disimpan'); window.location.assign('admin.php?url=lihat-petugas');</script>";
    <?php
}
?>