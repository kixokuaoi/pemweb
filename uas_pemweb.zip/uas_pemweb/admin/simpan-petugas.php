<?php
include '../koneksi.php';
$nama = $_POST['nama_petugas'];
$email = $_POST['email'];
$password = $_POST['password'];
$telp = $_POST['telp'];
$level = $_POST['level'];

$sql = "INSERT INTO petugas(nama_petugas,email,password,telp,level) VALUES('$nama','$email','$password','$telp','$level')";
$query   = mysqli_query($koneksi, $sql);

if($query){
    ?>
    echo"<script>alert('Data Berhasil Disimpan'); window.location.assign('admin.php?url=lihat-petugas');</script>";
    <?php
}
?>