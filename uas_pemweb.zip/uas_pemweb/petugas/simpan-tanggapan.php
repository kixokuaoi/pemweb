<?php
include '../koneksi.php';
$id_pengaduan   = $_POST['id_pengaduan'];
$tgl_tanggapan  = $_POST['tgl_tanggapan'];
$tanggapan      = $_POST['tanggapan'];
$id_petugas     = $_POST['id_petugas'];
$status         = 'selesai';


$sql = "INSERT INTO tanggapan(id_pengaduan,tgl_tanggapan,tanggapan_id_petugas) VALUES('$id_pengaduan','$tgl_tanggapan','$tanggapan','$id_petugas')"
$update_status = mysqli_query("UPDATE pengaduan set status='$status' where id_pengaduan='$id_pengaduan'");

if($sql){
    ?>
    <script>alert('Data Sudah Ditanggapi'); window.location.assign('petugas.php?tanggapi-pengaduan.php'); </script>

<?php
}

?>