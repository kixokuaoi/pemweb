<?php

$nik        = $_POST['nik'];
$nama       = $_POST['nama'];
$email      = $_POST['email'];
$password   = $_POST['password'];
$telp       = $_POST['telp'];

include 'koneksi.php';
 
$sql     = "INSERT INTO masyarakat(nik, nama, email, password, telp) VALUES('$nik','$nama','$email','$password','$telp')";

$query   = mysqli_query($koneksi, $sql);

if($query){
    echo"<script>alert('Anda Berhasil Mendaftar'); window.location.assign('index.php');</script>";
}else{
    echo"<script>alert('Anda Gagal Mendaftar'); window.location.assign('register.php');</script>";
}